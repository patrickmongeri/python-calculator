# Scientific_Calculator-Django-Project-

# Scientific Calculator

# Python Version 3.7.4

# Django Version 3.0.5


This was developed Patrick Mongeri
